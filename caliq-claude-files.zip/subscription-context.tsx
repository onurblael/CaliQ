import React, { createContext, useContext, useEffect, useState, useCallback, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Plan Types
export type PlanType = "free" | "pro" | "pro_plus";

export interface PlanLimits {
  mealScansPerDay: number; // -1 = unlimited
  fridgeScansPerDay: number; // 0 = not available, -1 = unlimited
  recipeSuggestions: boolean;
  weeklyPlanning: boolean;
  shoppingList: boolean;
  optimizedRecipes: boolean;
  metabolicConsistency: boolean;
}

export interface Plan {
  id: PlanType;
  name: string;
  price: number; // monthly price in EUR
  yearlyPrice: number; // yearly price in EUR
  limits: PlanLimits;
  features: string[];
  popular?: boolean;
  badge?: string;
}

export const PLANS: Record<PlanType, Plan> = {
  free: {
    id: "free",
    name: "Free",
    price: 0,
    yearlyPrice: 0,
    limits: {
      mealScansPerDay: 5,
      fridgeScansPerDay: 0,
      recipeSuggestions: false,
      weeklyPlanning: false,
      shoppingList: false,
      optimizedRecipes: false,
      metabolicConsistency: false,
    },
    features: [
      "Scan de refeições (5x/dia)",
      "Tracking com intervalos calóricos",
      "Histórico de refeições",
      "Alinhamento com objetivo",
    ],
  },
  pro: {
    id: "pro",
    name: "Pro",
    price: 4.99,
    yearlyPrice: 39.99,
    limits: {
      mealScansPerDay: 15,
      fridgeScansPerDay: 1,
      recipeSuggestions: true,
      weeklyPlanning: false,
      shoppingList: false,
      optimizedRecipes: false,
      metabolicConsistency: false,
    },
    features: [
      "Tudo do Free +",
      "Scan de frigorífico (1x/dia)",
      "Sugestões de receitas básicas",
      "Ajuste ao objetivo calórico diário",
      "Scan de refeições (15x/dia)",
    ],
    popular: true,
    badge: "Mais Popular",
  },
  pro_plus: {
    id: "pro_plus",
    name: "Pro+",
    price: 9.99,
    yearlyPrice: 79.99,
    limits: {
      mealScansPerDay: -1,
      fridgeScansPerDay: -1,
      recipeSuggestions: true,
      weeklyPlanning: true,
      shoppingList: true,
      optimizedRecipes: true,
      metabolicConsistency: true,
    },
    features: [
      "Tudo do Pro +",
      "Scan ilimitado",
      "Planeamento semanal automático",
      "Receitas otimizadas por tempo",
      "Consistência metabólica",
      "Lista de compras integrada",
    ],
    badge: "Para Sérios",
  },
};

// Usage tracking
export interface DailyUsage {
  date: string; // YYYY-MM-DD
  mealScans: number;
  fridgeScans: number;
}

export interface Subscription {
  plan: PlanType;
  startDate: string | null;
  endDate: string | null;
  isActive: boolean;
  billingCycle: "monthly" | "yearly";
}

const DEFAULT_SUBSCRIPTION: Subscription = {
  plan: "free",
  startDate: null,
  endDate: null,
  isActive: true,
  billingCycle: "monthly",
};

const STORAGE_KEY = "@truthcalories_subscription";
const USAGE_KEY = "@truthcalories_usage";

// Helper
function getTodayString(): string {
  return new Date().toISOString().split("T")[0];
}

// Context
interface SubscriptionContextType {
  subscription: Subscription;
  currentPlan: Plan;
  dailyUsage: DailyUsage;
  loading: boolean;
  canScanMeal: () => boolean;
  canScanFridge: () => boolean;
  canAccessRecipes: () => boolean;
  canAccessWeeklyPlanning: () => boolean;
  canAccessShoppingList: () => boolean;
  incrementMealScan: () => void;
  incrementFridgeScan: () => void;
  getRemainingMealScans: () => number;
  getRemainingFridgeScans: () => number;
  upgradePlan: (plan: PlanType, cycle: "monthly" | "yearly") => void;
  cancelSubscription: () => void;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

// Provider
export function SubscriptionProvider({ children }: { children: ReactNode }) {
  const [subscription, setSubscription] = useState<Subscription>(DEFAULT_SUBSCRIPTION);
  const [dailyUsage, setDailyUsage] = useState<DailyUsage>({
    date: getTodayString(),
    mealScans: 0,
    fridgeScans: 0,
  });
  const [loading, setLoading] = useState(true);

  const currentPlan = PLANS[subscription.plan];

  // Load data from storage
  useEffect(() => {
    const loadData = async () => {
      try {
        const [storedSub, storedUsage] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEY),
          AsyncStorage.getItem(USAGE_KEY),
        ]);

        if (storedSub) {
          const parsed = JSON.parse(storedSub) as Subscription;
          setSubscription(parsed);
        }

        if (storedUsage) {
          const parsed = JSON.parse(storedUsage) as DailyUsage;
          // Reset if it's a new day
          if (parsed.date === getTodayString()) {
            setDailyUsage(parsed);
          } else {
            setDailyUsage({
              date: getTodayString(),
              mealScans: 0,
              fridgeScans: 0,
            });
          }
        }
      } catch (error) {
        console.error("Failed to load subscription data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  // Save subscription
  const saveSubscription = useCallback(async (newSub: Subscription) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newSub));
    } catch (error) {
      console.error("Failed to save subscription:", error);
    }
  }, []);

  // Save usage
  const saveUsage = useCallback(async (newUsage: DailyUsage) => {
    try {
      await AsyncStorage.setItem(USAGE_KEY, JSON.stringify(newUsage));
    } catch (error) {
      console.error("Failed to save usage:", error);
    }
  }, []);

  // Check if can scan meal
  const canScanMeal = useCallback(() => {
    const limit = currentPlan.limits.mealScansPerDay;
    if (limit === -1) return true; // Unlimited
    return dailyUsage.mealScans < limit;
  }, [currentPlan, dailyUsage]);

  // Check if can scan fridge
  const canScanFridge = useCallback(() => {
    const limit = currentPlan.limits.fridgeScansPerDay;
    console.log("canScanFridge check - plan:", currentPlan.id, "limit:", limit, "used:", dailyUsage.fridgeScans);
    if (limit === 0) return false; // Not available
    if (limit === -1) return true; // Unlimited
    return dailyUsage.fridgeScans < limit;
  }, [currentPlan, dailyUsage]);

  // Check recipe access
  const canAccessRecipes = useCallback(() => {
    return currentPlan.limits.recipeSuggestions;
  }, [currentPlan]);

  // Check weekly planning access
  const canAccessWeeklyPlanning = useCallback(() => {
    return currentPlan.limits.weeklyPlanning;
  }, [currentPlan]);

  // Check shopping list access
  const canAccessShoppingList = useCallback(() => {
    return currentPlan.limits.shoppingList;
  }, [currentPlan]);

  // Increment meal scan
  const incrementMealScan = useCallback(() => {
    const today = getTodayString();
    setDailyUsage((prev) => {
      const newUsage = prev.date === today
        ? { ...prev, mealScans: prev.mealScans + 1 }
        : { date: today, mealScans: 1, fridgeScans: 0 };
      saveUsage(newUsage);
      return newUsage;
    });
  }, [saveUsage]);

  // Increment fridge scan
  const incrementFridgeScan = useCallback(() => {
    const today = getTodayString();
    setDailyUsage((prev) => {
      const newUsage = prev.date === today
        ? { ...prev, fridgeScans: prev.fridgeScans + 1 }
        : { date: today, mealScans: 0, fridgeScans: 1 };
      saveUsage(newUsage);
      return newUsage;
    });
  }, [saveUsage]);

  // Get remaining meal scans
  const getRemainingMealScans = useCallback(() => {
    const limit = currentPlan.limits.mealScansPerDay;
    if (limit === -1) return -1; // Unlimited
    return Math.max(0, limit - dailyUsage.mealScans);
  }, [currentPlan, dailyUsage]);

  // Get remaining fridge scans
  const getRemainingFridgeScans = useCallback(() => {
    const limit = currentPlan.limits.fridgeScansPerDay;
    if (limit === 0) return 0; // Not available
    if (limit === -1) return -1; // Unlimited
    return Math.max(0, limit - dailyUsage.fridgeScans);
  }, [currentPlan, dailyUsage]);

  // Upgrade plan (simulated - in real app would integrate with payment)
  const upgradePlan = useCallback((plan: PlanType, cycle: "monthly" | "yearly") => {
    console.log("upgradePlan called with:", plan, cycle);
    const now = new Date();
    const endDate = new Date(now);
    if (cycle === "monthly") {
      endDate.setMonth(endDate.getMonth() + 1);
    } else {
      endDate.setFullYear(endDate.getFullYear() + 1);
    }

    const newSub: Subscription = {
      plan,
      startDate: now.toISOString(),
      endDate: endDate.toISOString(),
      isActive: true,
      billingCycle: cycle,
    };

    console.log("Setting new subscription:", newSub);
    setSubscription(newSub);
    saveSubscription(newSub);
    
    // Also reset daily usage when upgrading
    const resetUsage: DailyUsage = {
      date: getTodayString(),
      mealScans: 0,
      fridgeScans: 0,
    };
    setDailyUsage(resetUsage);
    saveUsage(resetUsage);
  }, [saveSubscription, saveUsage]);

  // Cancel subscription
  const cancelSubscription = useCallback(() => {
    const newSub: Subscription = {
      ...DEFAULT_SUBSCRIPTION,
    };
    setSubscription(newSub);
    saveSubscription(newSub);
  }, [saveSubscription]);

  return (
    <SubscriptionContext.Provider
      value={{
        subscription,
        currentPlan,
        dailyUsage,
        loading,
        canScanMeal,
        canScanFridge,
        canAccessRecipes,
        canAccessWeeklyPlanning,
        canAccessShoppingList,
        incrementMealScan,
        incrementFridgeScan,
        getRemainingMealScans,
        getRemainingFridgeScans,
        upgradePlan,
        cancelSubscription,
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
}

// Hook
export function useSubscription() {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error("useSubscription must be used within a SubscriptionProvider");
  }
  return context;
}
